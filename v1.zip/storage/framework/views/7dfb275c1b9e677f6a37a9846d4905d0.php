

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editar Livro</h1>
    <form action="<?php echo e(route('books.update', $book->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Título:</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo e($book->title); ?>" required>
        </div>
        <div class="form-group">
            <label for="subtitle">Subtítulo:</label>
            <input type="text" class="form-control" id="subtitle" name="subtitle" value="<?php echo e($book->subtitle); ?>">
        </div>
        <div class="form-group">
            <label for="author">Autor:</label>
            <input type="text" class="form-control" id="author" name="author" value="<?php echo e($book->author); ?>" required>
        </div>
        <div class="form-group">
            <label for="publisher">Editora:</label>
            <input type="text" class="form-control" id="publisher" name="publisher" value="<?php echo e($book->publisher); ?>">
        </div>
        <div class="form-group">
            <label for="edition">Edição:</label>
            <input type="text" class="form-control" id="edition" name="edition" value="<?php echo e($book->edition); ?>">
        </div>
        <div class="form-group">
            <label for="year">Ano:</label>
            <input type="text" class="form-control" id="year" name="year" value="<?php echo e($book->year); ?>">
        </div>
        <div class="form-group">
            <label for="cover">Capa do Livro:</label>
            <input type="file" class="form-control" id="cover" name="cover">
        </div>
        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thiag\OneDrive\Documentos\Laravel\livraria\resources\views/books/edit.blade.php ENDPATH**/ ?>